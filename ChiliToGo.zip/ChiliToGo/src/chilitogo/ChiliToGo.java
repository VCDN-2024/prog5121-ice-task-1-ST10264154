
package chilitogo;
import java.util.Scanner;

public class ChiliToGo {
public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Huntington Boys and Girls Club Chili Fundraiser!");
        System.out.println("The price for adult meals costs $7 and child meals costs $4.");

        System.out.print("Enter the number of adult meals ordered: ");
        int adultMeals = scanner.nextInt();

        System.out.print("Enter the number of child meals ordered: ");
        int childMeals = scanner.nextInt();

        int totalAdultCost = adultMeals * 7;
        int totalChildCost = childMeals * 4;
        int totalCost = totalAdultCost + totalChildCost;

        System.out.println("\nThank you for your order!");
        System.out.println("Total money collected for adult meals: $" + totalAdultCost);
        System.out.println("Total money collected for child's meals: $" + totalChildCost);
        System.out.println("Total money collected for both meals: $" + totalCost);

        scanner.close();
    }
}